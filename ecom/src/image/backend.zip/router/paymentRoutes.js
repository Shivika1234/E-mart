const express = require('express')
const paymentRoute = express.Router()


const { checkout, paymentVerification } = require("../Controller/payment.controller")

paymentRoute.post("/checkout",checkout)
paymentRoute.post("/paymentverification",paymentVerification)

module.exports={paymentRoute}