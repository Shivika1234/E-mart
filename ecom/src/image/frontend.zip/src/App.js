import Checkout from "./components/Checkout";
import { Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import PaymentSuccess from "./components/PaymentSuccess";

function App() {
  return (
    <div className="App">
      
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/checkoutpage" element={<Checkout />} />
        <Route path="/paymentsuccess" element={<PaymentSuccess />} />
      </Routes>
    </div>
  );
}

export default App;
