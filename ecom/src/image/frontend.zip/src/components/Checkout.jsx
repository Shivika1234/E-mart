import React from 'react'

function Checkout() {
  return (
    <>
    <form className='w-75 p-5'>
    <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"/>
    
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"/>
     
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">phone number</label>
    <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"/>
     
  </div>
  <div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">Address</label>
  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
</div>
  
  <button type="submit" class="btn btn-primary">Pay</button>
</form>
    </>
  )
}

export default Checkout
