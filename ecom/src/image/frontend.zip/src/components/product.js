import React from "react";
const image1 =
  "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAHoAtgMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAAAgQFBgcIAwH/xAA8EAABAwIDBAYHBgYDAAAAAAABAAIDBBEFEiEGBzFBEyJRYXGRFDKBobGywRUzQlJy0SMmNqLC8EVi4f/EABYBAQEBAAAAAAAAAAAAAAAAAAABAv/EABYRAQEBAAAAAAAAAAAAAAAAAAARMf/aAAwDAQACEQMRAD8A3iiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIisW1O1mFbKx08mMSSxsqHlkZjiL9QLm9kF9RYHBvZ2YmJDZKq97ACAm/7K77Rba4VgT3wTSGSpaPu2C9ieAJ5X9pUoyVFimDbd4ViFO+Wo6SiLHZQ2dpu8WBzCwvbUjUDgqfGN4mHUBi9Dp6nEc7gHCnic0xjtJcAD4DVKMzRYhV7x9naR7GSy1hztuHNopSPDhxXph28HZ7EKttNDUzRuIJzz0742DuzOAF0oytF5088VRE2WCVksbuD2OuD7V6KgiIgIiICIiAiIgIiICIiDH9r9q6PZalp56xjnieXIGsIu0WuXW4kcBYAm5CsTN6GDyNvHlI5XLwSPAsVp34UcL6OhrXA54X5fW4tPLs9q1VFT4OX9I6vc0kAlpGre5QZlje8LHajFagxVE9Nh4efRxSGIut33IJ7bnyWJ49jG0W0L2fbFZDUQMdmjilliGU2tfTtUvRcIygiqLwTb71g+JVvxOTDIXCCjkkknvqcwLWjxA1QSjpS0dUUcZH4mOYSPqq6WsdFFNW1Fa+sxCV338gPVJFi4acbDs+t7ZhlJLiNdFSxE5nntVZtLhTcJcwMmkkBIDs7S25ty8vegvB2Smf0T5MTiBlY9wLosxDmgE3ANxxUNn9o3ijLKs53xusHX9Yar5HtjiNZSGOPDmGVgMZqOlLXBthZrrdXgO5Y/FhVTI1zg6JpJJyGdhOpvyKDY2yU+zNdNiM201TC28rfRxPUPZZmXUAAi+oPmr5VnduyncIJqBzxwtLI8jt4krWVJU4dhtJT02KYR0j2ve6V7WMd6QDYs651ZlsRlGhDjeyq34/ss0tMWyETsp06ScdZtxodD36/QlSDKNhMebT7fChw2XPh1a8syN0bpGDmsRxBaRfv8FusLnHYd0GJbx6CWip24fA+pbIyCM3EYawEgaDQlp5fiXRy1gIiICIiAiIgIiICIiAiIg1lvwA+x8PPP0n/By0w1vWJ08luvfcB9h0OnW9KB/setK/iKgmCbclQGaQVrxnI0HqmyrtALq1SG2IyeAQVQq5qWoNTBK5kzDdrxxGiVeMVGIObVYjN0xbfICMo7zYD2dpVFXAl3RtNjI8C/YNFSyva95s2zGgG3w9yorhNVVb488jmt4MaG3Nu4cG+xXagware1swL2McbB76sC/0XnhdXBhdOJnguqpX5WuykmPw5E969ziFMHESuLJDc2k9bU3UHnLRVbITNHnqKVxIedTw7dB5ge0qic0NNxwPC/Hw/wDe9Vs2IQtzNLHm4GYG1i3t46hfJnx1cRmaMr3guIA00HEe/wA1RkO6kfzzhf63/I5dILnHdQP54wz9b/kcujkBERAREQEREBERAREQEREGu99jb7O0h7KsfK5aP4Eree+lgOy8D9bsqRb2tIWixdz8rGlziQGtGpJJsAFBIFWucXxNx8Fkn2Fi7c18PeA31v40XYD+fsINuKxyXrV5I4EBBCpF6qLsDyP7VClhEtc1hGjpW38rr2qGF7Tl9cODmnvUYndHUMqGC4JBtzuOXxHkgvNRGLwdEwBwc8tHflJHwCxqKMSB7pMrn3ubu4nn4lZRNFUTOYaJrpC277s42PMLyFDKXulfQvbLzMT2AHvF3Ajw1QWfI+KmY17rkOAN+Vx1grxhjR6DCB+Q/VQdhVVVyMY9kUEQ5dK11vI6k9vBTZG+ioXMeBnALAMw/wBNggyPdN/W2Gfqf8jl0cucN039cYb+t/yOXR6oIiICIiAiIgIiICIiAiIgwzerhkmIbJVEkIvLTWk8W3Gb4e5c8dJLHK17BZ7SHNIdYtI1vddYYhTsqqcwytzMcdR2rD5t2my87y9+HZXH8sz2/AqDRcuN4pIJWvqpCJgWvGfRwItbyFvBWWoc9sxebNGmoXRbd2Gyzf8Aj3HxqJD/AJKsh2A2ch+7wmnv2ubmPvRXMjqxjBa4dfjqqY1jWyXYLA8Rf3rqk7GYPazcPp2+EQVNNsNhzxZtNC3wZZBzrhuNxwN6KZjZIjwIPXZ4fssgbiWGTNJjnhkH4WyNLHcOZsQtr1G7WilPVETe7IvKHdlBG4OEkYtwtGiNWmoY5v8AApaipdyip4TlPi79uxUJwfaDEJ+k+xqm54NZHYN8Fv8AoNlG0bQ0SDT/AKq6xYd0Y1PuRWuN02wmJUOJsxrF4207YmOENPnDnlxFszspIAAvpx15WW3xwVHSwmOQEHlYqtVQREQEREBERAREQEREBERB8IuF8yqSII5UyqSII5UyqSII5UyqSII5UyhSRBENspIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiD/2Q==";
function product() {
  return (
    <>
      <div class="container">
        <div class="row">
          <div class="col-4">
            <div class="card" style="width: 18rem;">
              <img src="..." class="card-img-top" alt="..." />
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </p>
                <a href="#" class="btn btn-primary">
                  Go somewhere
                </a>
              </div>
            </div>
          </div>
          {/* <div class="col-4">
            <div class="card" style="width: 18rem;">
              <img src="..." class="card-img-top" alt="..." />
              <div class="card-body">
                <h5 class="card-title"></h5>
           
                <a href="#" class="btn btn-primary">
                  Go somewhere
                </a>
              </div>
            </div>
          </div> */}
          {/* <div class="col-4">
            <div class="card" style="width: 18rem;">
              <img src="..." class="card-img-top" alt="..." />
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </p>
                <a href="#" class="btn btn-primary">
                  Go somewhere
                </a>
              </div>
            </div>
          </div> */}
        </div>
      </div>
    </>
  );
}

export default product;
